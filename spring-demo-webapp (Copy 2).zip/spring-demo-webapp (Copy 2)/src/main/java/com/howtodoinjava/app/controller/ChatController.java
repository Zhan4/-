package com.howtodoinjava.app.controller;

import org.springframework.web.bind.annotation.*;
import java.util.Scanner;

@RestController
public class ChatController {

    @PostMapping("/chat")
    public Response chat(@RequestBody Request request) {
        System.out.println("User: " + request.getMessage());
        System.out.print("Assistant: ");

        Scanner scanner = new Scanner(System.in);
        String assistantResponse = scanner.nextLine();

        return new Response(assistantResponse);
    }

    public static class Request {
        private String message;

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    public static class Response {
        private String response;

        public Response(String response) {
            this.response = response;
        }

        public String getResponse() {
            return response;
        }

        public void setResponse(String response) {
            this.response = response;
        }
    }
}
