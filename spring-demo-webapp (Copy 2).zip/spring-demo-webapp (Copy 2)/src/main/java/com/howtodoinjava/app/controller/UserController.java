package com.howtodoinjava.app.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.howtodoinjava.app.exception.RecordNotFoundException;
import com.howtodoinjava.app.exception.ServerException;
import com.howtodoinjava.app.model.User;
import com.howtodoinjava.app.service.UserService;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;

@RestController
public class UserController {

	@Autowired
	UserService userService;

	@GetMapping("courses")
	public ResponseEntity<List<User>> getAll() {
		return new ResponseEntity<>(userService.getAll(), HttpStatus.OK);
	}

	@GetMapping("courses/{id}")
	public ResponseEntity<User> getById(@PathVariable final long id) {
		Optional<User> user = userService.getById(id);
		if (user.isPresent()) {
			return new ResponseEntity<>(user.get(), HttpStatus.OK);
		}
		else {
			throw new RecordNotFoundException();
		}
	}

	@PostMapping(path = "/courses",
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> createUser(@RequestBody User newUser, HttpServletRequest request) {

		User user = userService.save(newUser);
		if (user != null) {
			URI location = ServletUriComponentsBuilder.fromRequestUri(request)
					.path("/{id}")
					.buildAndExpand(user.getId())
					.toUri();
			return ResponseEntity.created(location).body(user);
		} else {
			throw new ServerException();
		}
	}


	@PutMapping("courses/{id}")
	public ResponseEntity<User> update(@RequestBody final User updatedUser) {
		User user = userService.save(updatedUser);
		if (user == null) {
			throw new ServerException();
		}
		else {
			return new ResponseEntity<>(user, HttpStatus.OK);
		}
	}

	@DeleteMapping("courses/{id}")
	public HttpStatus delete(@PathVariable final long id) {
		try {
			userService.delete(id);
			return HttpStatus.OK;
		}
		catch (Exception e) {
			throw new RecordNotFoundException();
		}
	}
}
