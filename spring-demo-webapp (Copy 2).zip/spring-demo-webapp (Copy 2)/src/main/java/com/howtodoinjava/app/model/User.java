package com.howtodoinjava.app.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "courses")
public class User implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Getter
	@Setter
	private long id;

	@Column(name = "name")
	@Getter
	@Setter
	private String name;

	@Column(name = "description")
	@Getter
	@Setter
	private String description;

	@Column(name = "mentor")
	@Getter
	@Setter
	private String mentor;



	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + name + ", "
				+ "lastName=" + description + ", email=" + mentor
				+ ", password="  + "]";
	}
}
