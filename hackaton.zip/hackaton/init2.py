from openai import OpenAI
client = OpenAI(api_key="sk-proj-8HYvtBtlomWIbbQPV1adT3BlbkFJbmuvYM2OcSObfCF035xN")
a = 'ftjob-lskYn0u6emVErhz3Mx5S94qd'

print(client.fine_tuning.jobs.create(
  training_file="file-3YjQuIUZXfWMWikvhzvhbTO7", 
  model="gpt-3.5-turbo"
))