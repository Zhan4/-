from openai import OpenAI
client = OpenAI(api_key="sk-proj-8HYvtBtlomWIbbQPV1adT3BlbkFJbmuvYM2OcSObfCF035xN")

print(client.files.create(
  file=open("teach.jsonl", "rb"),
  purpose="fine-tune"
))