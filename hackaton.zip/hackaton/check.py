from openai import OpenAI

# Replace with your OpenAI API key
api_key = 'sk-proj-8HYvtBtlomWIbbQPV1adT3BlbkFJbmuvYM2OcSObfCF035xN'
client = OpenAI(api_key=api_key)

# Replace with your fine-tuned model ID
model_id = 'ftjob-lskYn0u6emVErhz3Mx5S94qd'

# Generate a completion using the fine-tuned model
response = client.completions.create(
  model=model_id,
  prompt="What does impact admission do?",
  max_tokens=100
)
print(response['choices'][0]['text'])
